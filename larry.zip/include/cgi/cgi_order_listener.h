#ifndef __CGI_ORDER_LISTENER_H__
#define __CGI_ORDER_LISTENER_H__

#include <book/order_book.h>
#include <cgi/cgi_order_book.h>
#include <book/types.h>
#include <stdlib.h>
#include <string.h>

#include "boost/date_time/posix_time/posix_time.hpp"
#include <string>

namespace liquibook {
namespace cgi {

class TradeInfo {
public:
  uint32_t 	order_id_;
  char*   	char_order_id_;
  char* 	order_ids_user_;

  uint32_t 	matched_order_id_;
  char*   	char_matched_order_id_;
  char* 	matched_order_ids_user_;

  Quantity 	fill_qty_;
  Price 	cross_price_;
  uint32_t 	fill_flags_;
  bool  	is_buy_;
  char* 	created_at_;

public:
  TradeInfo( 	char* 		_char_order_id,
		char* 		_order_ids_user,
		char* 		_char_matched_order_id,
		char* 		_matched_order_ids_user,
		Price 		_cross_price,
		Quantity 	_fill_qty,
		uint32_t 	_fill_flags,
		bool 		_is_buy )
{
	char* _char_order_id_buffer = (char*)malloc( 32 );
	memset( _char_order_id_buffer, 0x0, 32);
	memcpy( _char_order_id_buffer, _char_order_id, 32);

	char* _char_matched_order_id_buffer = (char*)malloc(32);
	memset( _char_matched_order_id_buffer, 0x0, 32);
	memcpy( _char_matched_order_id_buffer, _char_matched_order_id, 32);

        char_order_id_       	= _char_order_id_buffer;

	order_ids_user_ 	= (char*)malloc(32);
	memset( order_ids_user_, 0x0, 32);
	memcpy( order_ids_user_, _order_ids_user, 32);

        char_matched_order_id_	= _char_matched_order_id_buffer;

	matched_order_ids_user_ = (char*)malloc( 32 );
	memset( matched_order_ids_user_, 0x0, 32);
	memcpy( matched_order_ids_user_, _matched_order_ids_user, 32);

        fill_qty_       	= _fill_qty;
        cross_price_    	= _cross_price;
        fill_flags_     	= _fill_flags;
	is_buy_ 		= _is_buy;

	boost::posix_time::ptime p = boost::posix_time::second_clock::local_time();
	std::string str_datetime = to_iso_extended_string( p );
	created_at_ = ( char* )malloc( 32 );
	memset( created_at_, 0x0, 32 );
	memcpy( created_at_, str_datetime.c_str(), 32 );
  }
};

using cgi::CgiOrder;
typedef CgiOrder* OrderPtr;

class CgiOrderListener: public book::OrderListener<OrderPtr>
{
public:
  virtual void on_accept(const OrderPtr& order)
  {
    // std::cerr << "\nCgiOrderListener::on_accept() called\n";
    // order->log_info();
    accepts_.push_back(order);
  }
  virtual void on_reject(const OrderPtr& order, const char* )
  {
    rejects_.push_back(order);
  }

  virtual void on_fill_v2( const OrderPtr& order, const OrderPtr& matched_order, Price price, Quantity quantity, uint32_t flags, bool is_buy ){
    fills_.push_back(order);
    TradeInfo *ti = new TradeInfo( order->char_order_id_, order->user_id_, matched_order->char_order_id_, matched_order->user_id_, price, quantity, flags, is_buy );
    fills_trade_info_.push_back( *ti );
  }

  virtual void on_fill( const OrderPtr&	order,
                        const OrderPtr& matched_order,
                        Quantity 	fill_qty,
                       	Cost 		fill_cost
			)
  {
    /*
    Quantity quantity = fill_qty;
    Cost cost = fill_cost;
    Price price = fill_cost / fill_qty;
    uint32_t flags = 0;
    fills_.push_back(order);
    TradeInfo *ti = new TradeInfo( order->char_order_id_, matched_order->char_order_id_, fill_qty, (uint32_t)(fill_cost / fill_qty), 0, true );
    fills_trade_info_.push_back( *ti );
    */
  }

  virtual void on_cancel(const OrderPtr& order)
  {
    cancels_.push_back(order);
  }
  virtual void on_cancel_reject(const OrderPtr& order, const char* )
  {
    cancel_rejects_.push_back(order);
  }
  virtual void on_replace(const OrderPtr& order,
                          const int32_t& , // size_delta
                          Price )          // new_price)
  {
    replaces_.push_back(order);
  }
  virtual void on_replace_reject(const OrderPtr& order, const char* )
  {
    replace_rejects_.push_back(order);
  }

  void reset()
  {
    accepts_.clear();
    rejects_.clear();
    fills_.clear();
    cancels_.clear();
    cancel_rejects_.clear();
    replaces_.clear();
    replace_rejects_.clear();
    fills_trade_info_.clear();
  }

public:
  // typedef std::vector<const CgiOrder*> OrderVector;
  typedef std::vector<CgiOrder*> OrderVector;
  OrderVector 	accepts_;
  OrderVector 	rejects_;
  OrderVector 	fills_;
  OrderVector 	cancels_;
  OrderVector 	cancel_rejects_;
  OrderVector 	replaces_;
  OrderVector 	replace_rejects_;

  std::vector<TradeInfo> fills_trade_info_;
};

}}

#endif
