// Copyright (c) 2012, 2013 Object Computing, Inc.
// All rights reserved.
// See the file license.txt for licensing information.
#pragma once

#include "cgi_order.h"
#include <book/depth_order_book.h>
#include <iostream>

using namespace liquibook;
using namespace liquibook::book;

namespace liquibook { namespace cgi {

// @brief binding of DepthOrderBook template with SimpleJsonOrder* order pointer.
template <int SIZE = 5>
class CgiOrderBook : public book::DepthOrderBook<CgiOrder*, SIZE> {
public:
  typedef book::Callback<CgiOrder*> CgiCallback;
  typedef uint32_t FillId;

  CgiOrderBook();

  // Override callback handling to update SimpleJsonOrder state
  virtual void perform_callback(CgiCallback& cb);
private:
  FillId fill_id_;
};

template <int SIZE>
CgiOrderBook<SIZE>::CgiOrderBook()
: fill_id_(0)
{
}

template <int SIZE>
inline void
CgiOrderBook<SIZE>::perform_callback(CgiCallback& cb)
{
  book::DepthOrderBook<CgiOrder*, SIZE>::perform_callback(cb);
  switch(cb.type) {
    case CgiCallback::cb_order_accept:
      cb.order->accept();
      break;
    case CgiCallback::cb_order_fill: {
      // Increment fill ID once
      ++fill_id_;
      // Update the orders
      book::Cost fill_cost = cb.quantity * cb.price;
      cb.matched_order->fill(cb.quantity, fill_cost, fill_id_);
      cb.order->fill(cb.quantity, fill_cost, fill_id_);
      break;
    }
    case CgiCallback::cb_order_cancel:
      cb.order->cancel();
      break;
    case CgiCallback::cb_order_replace:
      // Modify the order itself
      cb.order->replace(cb.delta, cb.price);
      break;
    default:
      // Nothing
      break;
  }
}
} }
