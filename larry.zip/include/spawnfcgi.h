#pragma once

#ifdef __cplusplus
extern "C" {
#endif

    int spawn_fcgi(int argc, char **argv);

#ifdef __cplusplus
}
#endif
