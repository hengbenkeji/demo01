#include "BookingAPIHandler.h"
#include "URL2ID.h"
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <map>
#include <string>

#include "boost/date_time/posix_time/posix_time.hpp"

using namespace liquibook::cgi;

BookingAPIHandler::BookingAPIHandler()
{}

BookingAPIHandler::~BookingAPIHandler()
{}

uint32_t BookingAPIHandler::get_price_by_order_id( std::string order_id )
{
	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			return el->price_;
		}
	}
	return -1;
}

uint32_t BookingAPIHandler::get_order_qty_by_order_id( std::string order_id ){
	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			return el->order_qty_;
		}
	}
	return -1;
}

uint32_t BookingAPIHandler::get_filled_qty_by_order_id( std::string order_id ){
	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			return el->filled_qty_;
		}
	}
	return -1;
}

bool BookingAPIHandler::get_buy_or_sell_by_order_id( std::string order_id ){
	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			return el->is_buy_;
		}
	}
	return false;
}

char* BookingAPIHandler::get_created_at_by_order_id( std::string order_id ){
	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			return el->created_at_;
		}
	}
	return NULL;
}

void BookingAPIHandler::HandleBookingAPI(RequestPtr request, const int id)
{
        switch( request->environment().requestMethod ){

        case RequestMethod::GET:
                ResponseError(request, ERR_NO_API);
                break;
        case RequestMethod::POST:
                switch( id ){
                case bookingapi:
                        ResponseBookingAPI( request );
                        break;
		case setmarketprice:
			ResponseSetMarketPrice( request );
			break;
		case cancelorder:
			ResponseCancelOrder( request );
			break;
		case info:
			ResponseInfo( request, NULL, NULL, NULL, NULL );
			break;
		case reset:
			ResponseReset( request );
			break;
		case stop:
			ResponseStop( request );
			break;
                default:
                        ResponseError( request, ERR_NO_API );
                        break;
                }
                break;
        default:
                ResponseError(request, ERR_NO_API);
                break;
        }
}


void BookingAPIHandler::ResponseInfo( RequestPtr request, char* _accepted_order = NULL, char* _accepted_at = NULL, char* _canceled_order = NULL, char* _canceled_at = NULL ){

	if( request->environment().requestMethod != RequestMethod::POST ){
		return ResponseError( request, ERR_NO_API );
	}

	const Json::Value & params = request->environment().jsons;

	if( !( params.isObject()) ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	int errCode = ERR_OK;
	Json::Value dataJson;

	bool has_user_id = params[ "user_id" ].isNull() == true ? false : true;

	if( !has_user_id ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	char* received_user_id = (char*)malloc( 32 );
	memset( received_user_id, 0x0, 32 );
	memcpy( received_user_id, params[ "user_id" ].asString().c_str(), 32 );

	if( _accepted_order != NULL ){
		dataJson[ "accepted_order" ] 	= _accepted_order;
	}
	else {
		dataJson[ "accepted_order" ] 	= Json::nullValue;
	}

	if( _accepted_at != NULL ){
		dataJson[ "accepted_at" ] 	= _accepted_at;
	}
	else {
		dataJson[ "accepted_at" ] 	= Json::nullValue;
	}

	if( _canceled_order != NULL ){
		dataJson[ "canceled_order" ] 	= _canceled_order;
	}
	else {
		dataJson[ "canceled_order" ] 	= Json::nullValue;
	}

	if( _canceled_at != NULL ){
		dataJson[ "canceled_at" ] 	= _canceled_at;
	}
	else {
		dataJson[ "canceled_at" ] 	= Json::nullValue;
	}

	dataJson[ "canceled_order_list" ]	= Json::arrayValue;

	for( auto & el: m_listener.cancels_ ){
		if( strcmp( received_user_id, el->user_id_ ) == 0 ){
			dataJson[ "canceled_order_list" ].append( el->char_order_id_ );
		}
	}

	dataJson[ "my_buys_order" ] = Json::arrayValue;
        std::vector<std::string> my_buys_order;

	dataJson[ "my_sells_order" ] = Json::arrayValue;
	std::vector<std::string> my_sells_order;

	for( auto & el : m_listener.accepts_ ){
		if( strcmp(received_user_id, el->user_id_ ) == 0 ){
			if( el->is_buy_ )
				my_buys_order.push_back( std::string( el->char_order_id_ ) );
			else
				my_sells_order.push_back( std::string( el->char_order_id_ ) );
		}
	}

	for( auto & el : my_buys_order ){
		dataJson[ "my_buys_order" ].append( el );
	}

	for( auto & el : my_sells_order ){
		dataJson[ "my_sells_order" ].append( el );
	}

	dataJson[ "my_buys_order_detail" ] = Json::nullValue;

	for( auto &el : my_buys_order ){
		dataJson[ "my_buys_order_detail" ][ el ][ "price" ] 		= get_price_by_order_id( el );
		dataJson[ "my_buys_order_detail" ][ el ][ "order_qty" ] 	= get_order_qty_by_order_id( el );
		dataJson[ "my_buys_order_detail" ][ el ][ "filled_qty" ] 	= get_filled_qty_by_order_id ( el );
		dataJson[ "my_buys_order_detail" ][ el ][ "is_buy" ] 		= get_buy_or_sell_by_order_id ( el );
		dataJson[ "my_buys_order_detail" ][ el ][ "order_created_at" ] 	= get_created_at_by_order_id ( el );
		dataJson[ "my_buys_order_detail" ][ el ][ "trade" ]		= Json::nullValue;

		int j = 0;
		for( auto & fel : m_listener.fills_trade_info_ ){
		        if( strcmp( fel.char_order_id_, el.c_str() ) == 0 ){
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "order_id" ]              = fel.char_order_id_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "order_ids_user" ]        = fel.order_ids_user_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_order_id" ]      = fel.char_matched_order_id_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_order_ids_user" ]= fel.matched_order_ids_user_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "cross_price" ]           = fel.cross_price_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "trade_qty" ]              = fel.fill_qty_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "inbound_filled" ]        = (fel.fill_flags_ == 1 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_filled" ]        = (fel.fill_flags_ == 2 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "type" ]                  = fel.is_buy_ ? "buy" : "sell";
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "trade_created_at" ]      = fel.created_at_;
		                j++;
		        }
		}

		j = 0;
		for( auto & fel : m_listener.fills_trade_info_ ){
		        if( strcmp( fel.char_matched_order_id_, el.c_str() ) == 0 ){
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "order_id" ]              = fel.char_order_id_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "order_ids_user" ]        = fel.order_ids_user_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_order_id" ]      = fel.char_matched_order_id_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_order_ids_user" ]= fel.matched_order_ids_user_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "cross_price" ]           = fel.cross_price_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "trade_qty" ]              = fel.fill_qty_;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "inbound_filled" ]        = (fel.fill_flags_ == 1 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_filled" ]        = (fel.fill_flags_ == 2 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "type" ]                  = fel.is_buy_ ? "buy" : "sell";
		                dataJson[ "my_buys_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "trade_created_at" ]            = fel.created_at_;
		                j++;
		        }
		}

	}

        dataJson[ "my_sells_order_detail" ] = Json::nullValue;

        for( auto &el : my_sells_order ){
                dataJson[ "my_sells_order_detail" ][ el ][ "price" ]             = get_price_by_order_id( el );
                dataJson[ "my_sells_order_detail" ][ el ][ "order_qty" ]         = get_order_qty_by_order_id( el );
                dataJson[ "my_sells_order_detail" ][ el ][ "filled_qty" ]        = get_filled_qty_by_order_id ( el );
                dataJson[ "my_sells_order_detail" ][ el ][ "is_buy" ]            = get_buy_or_sell_by_order_id ( el );
		dataJson[ "my_sells_order_detail" ][ el ][ "order_created_at" ] 	 = get_created_at_by_order_id ( el );
                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ]             = Json::nullValue;

                int j = 0;
                for( auto & fel : m_listener.fills_trade_info_ ){
                        if( strcmp( fel.char_order_id_, el.c_str() ) == 0 ){
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "order_id" ]              = fel.char_order_id_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "order_ids_user" ]        = fel.order_ids_user_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_order_id" ]      = fel.char_matched_order_id_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_order_ids_user" ]= fel.matched_order_ids_user_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "cross_price" ]           = fel.cross_price_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "trade_qty" ]              = fel.fill_qty_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "inbound_filled" ]        = (fel.fill_flags_ == 1 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "matched_filled" ]        = (fel.fill_flags_ == 2 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "type" ]                  = fel.is_buy_ ? "buy" : "sell";
		                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "active" ][ j ][ "trade_created_at" ]            = fel.created_at_;
                                j++;
                        }
                }


                j = 0;
                for( auto & fel : m_listener.fills_trade_info_ ){
                        if( strcmp( fel.char_matched_order_id_, el.c_str() ) == 0 ){
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "order_id" ]              = fel.char_order_id_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "order_ids_user" ]        = fel.order_ids_user_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_order_id" ]      = fel.char_matched_order_id_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_order_ids_user" ]= fel.matched_order_ids_user_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "cross_price" ]           = fel.cross_price_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "trade_qty" ]              = fel.fill_qty_;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "inbound_filled" ]        = (fel.fill_flags_ == 1 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "matched_filled" ]        = (fel.fill_flags_ == 2 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "type" ]                  = fel.is_buy_ ? "buy" : "sell";
		                dataJson[ "my_sells_order_detail" ][ el ][ "trade" ][ "passive" ][ j ][ "trade_created_at" ]           	= fel.created_at_;
                                j++;
                        }
                }
        }

	dataJson[ "bids" ] = Json::arrayValue;
	dataJson[ "asks" ] = Json::arrayValue;

	std::map<int, int> bids_map;
	std::map<int, int>::iterator bids_map_iter;
	for( auto & el: m_cgi_order_book.bids_ ){
		bids_map_iter = bids_map.find( el.first.price() );
		if( bids_map_iter == bids_map.end() ){
			bids_map.insert( std::make_pair( el.first.price(), el.second.open_qty() ) );
		}
		else {
			bids_map[ el.first.price() ] += el.second.open_qty();
		}
	}

	int i = 0;
	for( auto & el: bids_map ){
		dataJson[ "bids" ][ i ][ "price" ] = el.first;
		dataJson[ "bids" ][ i ][ "qty" ] = el.second;
		i++;
	}

        std::map<int, int> asks_map;
        std::map<int, int>::iterator asks_map_iter;
        for( auto & el: m_cgi_order_book.asks_ ){
                asks_map_iter = asks_map.find( el.first.price() );
                if( asks_map_iter == asks_map.end() ){
                        asks_map.insert( std::make_pair( el.first.price(), el.second.open_qty() ) );
                }
                else {
                        asks_map[ el.first.price() ] += el.second.open_qty();
                }
        }

        i = 0;
        for( auto & el: asks_map ){
                dataJson[ "asks" ][ i ][ "price" ] 	= el.first;
                dataJson[ "asks" ][ i ][ "qty" ] 	= el.second;
                i++;
        }

	if( m_cgi_order_book.market_price_v2() == 0  )
		dataJson[ "price" ] = m_price;
	else
		dataJson[ "price" ] = m_cgi_order_book.market_price_v2();

	Json::Value retJson;
	retJson[ "errcode" ] 	= errCode;
	retJson[ "data" ] 	= dataJson;
	ResponseJson( request, retJson );
}

void BookingAPIHandler::ResponseSetMarketPrice( RequestPtr request ){
	int errCode = ERR_OK;
	Json::Value retJson;
	retJson[ "errcode" ] = errCode;
	retJson[ "data" ] = "data";
	ResponseJson( request, retJson );
}

void BookingAPIHandler::ResponseReset( RequestPtr request ){
	int errCode = ERR_OK;
	Json::Value retJson;

	m_listener.reset();
	m_cgi_order_book.reset();

        retJson[ "errcode" ] 	= errCode;
	retJson[ "data" ]	= "RESET SUCCESSFULLY";
	ResponseJson( request, retJson );
}

void BookingAPIHandler::ResponseStop( RequestPtr request ) {
	int errCode = ERR_OK;
	Json::Value retJson;

	m_db->SaveTradeInfo( m_cgi_order_book, m_listener, m_db );

	retJson[ "errcode" ] 	= errCode;
	retJson[ "data" ]	= "STOP SUCCESSFULLY";
	ResponseJson( request, retJson );
}

void BookingAPIHandler::ResponseCancelOrder( RequestPtr request ){
	int errCode = ERR_NO_ORDER;

	const Json::Value & params = request->environment().jsons;
	if( request->environment().requestMethod != RequestMethod::POST ){
		return ResponseError( request, ERR_NO_API );
	}
	if( !( params.isObject() ) ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	auto user_id 	= params[ "user_id" ].asString();
	auto order_id 	= params[ "order_id" ].asString();

	if( user_id.empty() ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}
	if( order_id.empty() ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	char* user_id_buffer = (char*)malloc( 32 );
	memset( user_id_buffer, 0, 32 );
	memcpy( user_id_buffer, user_id.c_str(), 32);

	char* char_order_id = (char*)malloc( 32 );
	memset( char_order_id, 0, 32 );
	memcpy( char_order_id, order_id.c_str(), 32);

	boost::posix_time::ptime p = boost::posix_time::second_clock::local_time();
	std::string str_datetime = to_iso_extended_string( p );

	char* canceled_at = (char*)malloc( 32 );
	memset( canceled_at, 0x0, 32 );
	memcpy( canceled_at, str_datetime.c_str(), 32 );

	bool in_accepts = false;

	for ( auto & el: m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0){
			in_accepts = true;
		}
	}

	if( !in_accepts ){
		return ResponseError( request, ERR_NO_ORDER, "取消订单操作出错，该订单不存在" );
	}

	bool already_filled =false;

	for( auto & el : m_listener.accepts_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			if( el->order_qty_ == el->filled_qty_ ){
				already_filled = true;
			}
		}
	}

	if( already_filled ){
		return ResponseError( request, ERR_ALREADY_FILLED, "该订单已经完全成交，无法取消" );
	}

	bool in_cancels = false;

	for( auto & el : m_listener.cancels_ ){
		if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0 ){
			in_cancels = true;
		}
	}


	bool in_bids_or_asks = false;

	for( auto & el : m_cgi_order_book.bids_ ){
		if( strcmp( order_id.c_str(), el.second.ptr()->char_order_id_ ) == 0 ){
			in_bids_or_asks = true;
		}
	}

	for( auto & el : m_cgi_order_book.asks_ ){
		if( strcmp( order_id.c_str(), el.second.ptr()->char_order_id_ ) == 0 ){
			in_bids_or_asks = true;
		}
	}

	if( !in_cancels ){
		for ( auto & el: m_listener.accepts_ ){
			if( strcmp( order_id.c_str(), el->char_order_id_ ) == 0){
				m_cgi_order_book.cancel( el );
				errCode = ERR_OK;
			}
		}
	}

	if( in_cancels ) {
		ResponseInfo( request, NULL, NULL, NULL, NULL );
	}
	else {
		ResponseInfo( request, NULL, NULL, char_order_id, canceled_at );
	}

}

void BookingAPIHandler::ResponseBookingAPI(RequestPtr request){
	const Json::Value & params = request->environment().jsons;
        if( request->environment().requestMethod != RequestMethod::POST ){
		ResponseError( request, ERR_NO_API);
		return;
	}
	if(! ( params.isObject() ) ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}
	auto user_id 	= params[ "user_id" ].asString();
        auto order_id   = params[ "order_id" ].asString();
       	auto is_buy     = params[ "is_buy" ].asBool();
        auto price      = params[ "price" ].asUInt();
        auto qty        = params[ "qty" ].asUInt();

	bool duplicated_order_id = false;

	if( user_id.empty() ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	if( order_id.empty() ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	if( price == 0 ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	if( qty == 0 ){
		return ResponseError( request, ERR_NO_PARAMETER );
	}

	for( auto & el: m_cgi_order_book.bids_ ){
		if(order_id == el.second.ptr()->char_order_id_ ){
			duplicated_order_id = true;
		}
	}

	for( auto & el: m_cgi_order_book.asks_ ){
		if(order_id == el.second.ptr()->char_order_id_ ){
			duplicated_order_id = true;
		}
	}

	for( auto & el: m_listener.accepts_ ){
		if(order_id == el->char_order_id_){
			duplicated_order_id = true;
		}
	}

	if( duplicated_order_id ){
		return ResponseError( request, ERR_DUPLICATED_ORDER, "重复的订单ID" );
	}

	char* user_id_buffer = (char*)malloc( 32 );
	memset( user_id_buffer, 0, 32 );
	memcpy( user_id_buffer, user_id.c_str(), 32);

	char* char_order_id = (char*)malloc( 32 );
	memset( char_order_id, 0, 32 );
	memcpy( char_order_id, order_id.c_str(), 32);

	boost::posix_time::ptime p = boost::posix_time::second_clock::local_time();
	std::string str_datetime = to_iso_extended_string( p );

	char* created_at = (char*)malloc( 32 );
	memset( created_at, 0x0, 32 );
	memcpy( created_at, str_datetime.c_str(), 32 );

	m_listener.fills_trade_info_.reserve( 512 );

	cgi::CgiOrder* order = new cgi::CgiOrder( user_id_buffer, char_order_id, created_at, is_buy, price, qty );
	m_cgi_order_book.add( order );

	int errCode = ERR_OK;
	Json::Value dataJson;

	if( order->order_id_ != m_listener.accepts_.back()->order_id_ ){
		dataJson[ "accepted_order" ] = Json::nullValue;
		dataJson[ "created_at" ] = Json::nullValue;
		ResponseError( request, ERR_SERVER, "Booking Server Fatal Error!" );
		return;
	}
	else {
		dataJson[ "accepted_order" ] 	= order->char_order_id_;
		dataJson[ "created_at" ] 	= order->created_at_;
	}

	ResponseInfo( request, order->char_order_id_, order->created_at_, NULL, NULL );
}
