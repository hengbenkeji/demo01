#ifndef __BOOKING_API_H_
#define __BOOKING_API_H_

#include "BaseHandler.h"

#include <iostream>
#include <string>
#include <map>
#include <vector>

class BookingAPIHandler : public virtual BaseHandler
{
public:
	BookingAPIHandler();
	virtual ~BookingAPIHandler();

protected:
	void HandleBookingAPI(RequestPtr request, const int id);

private:
	void ResponseInfo( RequestPtr request, char* _accepted_order, char* _accepted_at, char* _canceled_order, char* _canceled_at );

	void ResponseReset		( RequestPtr request );
	void ResponseStop 		( RequestPtr request );

	void ResponseCancelOrder	( RequestPtr request );
	void ResponseSetMarketPrice	( RequestPtr request );
	void ResponseBookingAPI		( RequestPtr request );
	void ResponseBookingSimpleOrder	( RequestPtr request );

	uint32_t get_price_by_order_id		( std::string order_id );
	uint32_t get_order_qty_by_order_id	( std::string order_id );
	uint32_t get_filled_qty_by_order_id	( std::string order_id );
	bool 	 get_buy_or_sell_by_order_id	( std::string order_id );
	char* 	 get_created_at_by_order_id	( std::string order_id );
};

class TradeItem{
public:
	char* user_id_;
	char* order_id_;
	bool is_buy_;

	TradeItem( char* _user_id, char* _order_id, bool _is_buy)
	:user_id_( _user_id ),
	order_id_( _order_id ),
	is_buy_( _is_buy )
	{}
};

#endif
