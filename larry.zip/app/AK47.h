#pragma once
#include <string>

namespace AK47
{
    std::string GetErrMsg(int errCode);
};

