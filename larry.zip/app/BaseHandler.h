﻿#pragma once

#include "fastcgi++/request.hpp"
#include "fastcgi++/manager.hpp"
#include <iomanip>
#include <sstream>
#include "typeDef.h"
#include "json/json.h"  //Json
#include "DataBase.h"

#include <cgi/cgi_order_book.h>
#include <book/types.h>
#include <cgi/cgi_order_listener.h>

using namespace liquibook;
using namespace liquibook::book;
using namespace liquibook::cgi;

typedef cgi::CgiOrderBook<5> 		FullDepthOrderBook;
typedef cgi::CgiOrderBook<1> 		BboOrderBook;
typedef book::OrderBook<cgi::CgiOrder*>	NoDepthOrderBook;

using namespace Fastcgipp::Http;        //export RequestMethod::POST

typedef std::shared_ptr<Fastcgipp::Request<char>> RequestPtr;
typedef std::shared_ptr<Fastcgipp::Request_base> _RequestPtr;

class BaseHandler : public Fastcgipp::RequestHandler_base
{
public:
    BaseHandler();
    virtual ~BaseHandler();

    std::string Cookie2String(RequestPtr request);
    void LogRequest(RequestPtr request);
    int Response(RequestPtr request, const char* contentType, const char* content, int errcode);
    void ResponseJson(RequestPtr request, Json::Value& retJson);
    void ResponseError(RequestPtr request, int errcode, std::string paramMsg = "");

public:
    cgi::CgiOrderListener   m_listener;
    FullDepthOrderBook      m_cgi_order_book;
    int m_start_hour;
    int m_end_hour;
    int m_price;

public:
    std::shared_ptr<DataBase> m_db;
};
