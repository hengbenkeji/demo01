﻿#include "RequestHandler.h"
#include <boost/algorithm/string.hpp>   //split
#include "URL2ID.h"
#include "typeDef.h"

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>

#include "boost/date_time/posix_time/posix_time.hpp"

RequestHandler::RequestHandler()
{
}


RequestHandler::~RequestHandler()
{
}

bool RequestHandler::Handle(_RequestPtr _request)
{
    using namespace boost::posix_time;
    using namespace boost::gregorian;

    RequestPtr request = std::dynamic_pointer_cast<Fastcgipp::Request<char>>(_request);

    //log
    LogRequest(request);

    //check time table
    ptime now = second_clock::local_time();
    int hour = now.time_of_day().hours();
    if( hour < m_start_hour || hour > m_end_hour ){
	ResponseError( request, ERR_NOT_SCHEDULED, "根据日程安排，现在不是开盘时间" );
	return true;
    }

    //处理业务
    std::vector<std::string> path;
    boost::split(path, request->environment().scriptName, boost::is_any_of("/"));

    if (path.size() < 3)
    {
        ResponseError(request, ERR_NO_API);
        return true;
    }

    auto moduleId = URL2ID::FindMid(path[1]);
    auto id = URL2ID::FindId( path[2].substr(0, path[2].length() - 4 ) );

    switch (moduleId)
    {
    case OpenAPI:
        HandleOpenAPI(request, id);
        break;
    case UserAuth:
        HandleUserAuth(request, id);
        break;
    case booking:
   	HandleBookingAPI(request, id);
        break;
    default:
        ResponseError(request, ERR_NO_API);
        break;
    }
    return true;
}
