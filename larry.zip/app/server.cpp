//! See https://isatec.ca/fastcgipp/helloWorld.html
//! [Request definition]

#include <fastcgi++/request.hpp>
#include "spawnfcgi.h"

#include <fastcgi++/manager.hpp>
#include "URL2ID.h"
#include "log.h"

#include <iomanip>
#include <iostream>
#include "RequestHandler.h"

int main( int argc, char ** argv )
{
    if( 0 == spawn_fcgi( argc, argv ) ){
	URL2ID::Init();
	common::InitLog();

    	Fastcgipp::Manager<RequestHandler> manager;
    	//! [Manage]
	//! [Signals]
    	manager.setupSignals();
    	//! [Signals]
    	//! [Listen]
    	manager.listen();
    	//! [Listen]
    	//! [Start]
    	manager.start();
    	//! [Start]
    	//! [Join]
    	manager.join();

    	return 0;
    }
}
