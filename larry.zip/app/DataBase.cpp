#include "DataBase.h"

#include <boost/date_time.hpp>
#include <algorithm>
#include <vector>
#include <string>

#include <iostream>
#include <sstream>

using namespace boost::posix_time;
using namespace std;

DataBase::DataBase()
{}


DataBase::~DataBase()
{}

bool DataBase::GetWeTestData(Json::Value& data)
{
    bool ret = false;
    std::string sql = "select * from t_user";
    try
    {
        std::unique_ptr<sql::ResultSet> pRes(ExecuteQuery(sql));
        if (pRes && pRes->next())
        {
            data["name"] = pRes->getString("name").asStdString();
            data["phone"] = pRes->getString("phone").asStdString();
            ret = true;
        }
    }
    catch (sql::SQLException& e)
    {
        LogSqlException(e, "GetWeTestData", sql);
        HandleException(e);
    }
    return ret;
}

bool DataBase::GetTimeTable(Json::Value& data)
{
    bool ret = false;
    boost::posix_time::ptime timeLocal = boost::posix_time::second_clock::local_time();
    boost::gregorian::date dateObj = timeLocal.date();
    std::string strDate = to_iso_extended_string( dateObj );
    std::string sql = "SELECT * FROM t_timetable WHERE `date`='" + strDate+ "'; ";

    try
    {
    	std::unique_ptr<sql::ResultSet> pRes(ExecuteQuery(sql));
    	if (pRes && pRes->next())
    	{
		int start 	= pRes->getInt( "start" );
		int end 	= pRes->getInt( "end" );
		int price0 	= pRes->getInt( "price0" );
		data[ "start" ] = start;
		data[ "end" ] 	= end;
		data[ "price0" ]= price0;
		ret = true;
    	}
    }
    catch (sql::SQLException& e)
    {
        LogSqlException(e, "GetWeTestData", sql);
        HandleException(e);
    }
    return ret;
}

bool DataBase::SaveTradeInfo( FullDepthOrderBook & m_order_book, cgi::CgiOrderListener & m_listener, std::shared_ptr<DataBase> & _m_db  ){
	bool ret = false;

    	boost::posix_time::ptime timeLocal = boost::posix_time::second_clock::local_time();
    	boost::gregorian::date dateObj = timeLocal.date();
    	std::string strDate = to_iso_extended_string( dateObj );

	sql::PreparedStatement * removeDuplicate;
	removeDuplicate = _m_db->PrepareStatement("DELETE FROM records WHERE LEFT( `trade_created_at`, 10 )=?;");
	removeDuplicate->setString( 1, strDate );
	removeDuplicate->executeUpdate();

	sql::PreparedStatement * pstmt;
	pstmt = _m_db->PrepareStatement(
		"INSERT INTO records( `order_id`, `order_ids_user`, `matched_order_id`, `matched_order_ids_user`, `cross_price`, `trade_qty`, `inbound_filled`, `matched_filled`, `type`, `trade_created_at` ) VALUES(?,?,?,?,?,?,?,?,?,?);");

	for( auto & fel : m_listener.fills_trade_info_ ){
		char* char_order_id 		= fel.char_order_id_;
               	char* order_ids_user        	= fel.order_ids_user_;
                char* matched_order_id      	= fel.char_matched_order_id_;
                char* matched_order_ids_user	= fel.matched_order_ids_user_;
                int cross_price           	= fel.cross_price_;
                int trade_qty              	= fel.fill_qty_;
                int inbound_filled        	= (fel.fill_flags_ == 1 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                int matched_filled        	= (fel.fill_flags_ == 2 ) || ( fel.fill_flags_ == 3) ? 1 : 0 ;
                const char* type              	= fel.is_buy_ ? "buy" : "sell";
                char* trade_created_at      	= fel.created_at_;

		pstmt->setString(1, char_order_id );
		pstmt->setString(2, order_ids_user );
		pstmt->setString(3, matched_order_id );
		pstmt->setString(4, matched_order_ids_user );
		pstmt->setInt(5, cross_price );
		pstmt->setInt(6, trade_qty );
		pstmt->setInt(7, inbound_filled );
		pstmt->setInt(8, matched_filled );
		pstmt->setString(9, type );
		pstmt->setString(10, trade_created_at );

		pstmt->executeUpdate();
	}

	delete pstmt;
	return ret;
}
