#pragma once
#include "mysqlwrapper.h"
#include "json/json.h"  //Json

#include <cgi/cgi_order_book.h>
#include <book/types.h>
#include <cgi/cgi_order_listener.h>

#include <iostream>
#include <sstream>

using namespace liquibook;
using namespace liquibook::book;
using namespace liquibook::cgi;

class DataBase : public MySQLWrapper
{
public:
    typedef cgi::CgiOrderBook<5> FullDepthOrderBook;

public:
    DataBase();
    ~DataBase();
    bool GetWeTestData(Json::Value& data);
    bool GetTimeTable(Json::Value& data );

    bool SaveTradeInfo(FullDepthOrderBook & m_order_book, cgi::CgiOrderListener & m_listener, std::shared_ptr<DataBase> & _m_db  );
};
