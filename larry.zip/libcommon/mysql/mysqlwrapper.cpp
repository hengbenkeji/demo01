//#pragma once
#include "mysqlwrapper.h"
#include "log.h"
#include <sstream>
#include <iostream>

using namespace std;

MySQLWrapper::MySQLWrapper() : m_driver(nullptr)
{
	// std::cerr << "##### MySQLWrapper::constructor()" <<"\n";
}

MySQLWrapper::~MySQLWrapper()
{
    if (m_con)
    {
        if (!m_con->isClosed())
            m_con->close();
    }
    m_con.reset();
}

bool MySQLWrapper::Init(std::string&& host, std::string&& user, std::string&& password, std::string&& dbname)
{
    // std::cerr << "##### MYSQLWrapper::Init()\n";

    std::unique_lock<std::mutex> lock(m_mutex);
    m_driver = sql::mysql::get_driver_instance();

    lock.unlock();

    if( m_driver ){
	// std::cerr << "##### m_driver is not NULL. :" << m_driver->getMajorVersion() << ":" << m_driver->getMinorVersion() << ":" << m_driver->getPatchVersion()  << "\n" ;
	sql::SQLString str = m_driver->getName();
	std::cerr << "##### MySQL driver: " << str.asStdString() << "\n";
    }
    else {
	std::cerr << "##### m_driver is NULL\n";
    }
    /*
    if( m_con )
	std::cerr << "##### m_con is not null" << "\n";
    else
	std::cerr << "##### m_con is null :" << host << ":" << user << ":" << password << ":" << dbname << "\n";
    */
    if (m_driver){
	// std::cerr << "##### before connect()\n";
	m_con.reset(m_driver->connect(host, user, password ));
	// m_driver->connect("tcp://127.0.0.1:3306", "root", "123qweASD__" );
	// std::cerr << "##### after connect()\n";
    }

    if (m_con)
    {
        m_con->setSchema(dbname);
        std::unique_ptr<sql::Statement> stmt(m_con->createStatement());
        stmt->execute("SET NAMES UTF8");

        m_host = host;
        m_user = user;
        m_password = password;
        m_dbname = dbname;
	std::cerr << "##### MySQL connect() success\n";

        Log(info, "connect mysql ok");
    }
    return m_con ? true : false;
}

void MySQLWrapper::LogSqlException(const sql::SQLException& e, const std::string& prefix, const std::string& sql)
{
    Log(error, "in %s.mysql ERROR %d (%s).sql:%s", prefix.c_str(), e.getErrorCode(), e.getSQLStateCStr(), e.what(), sql.c_str());
}

bool MySQLWrapper::HandleException(sql::SQLException& e)
{
    bool ret = false;
    if (2006 == e.getErrorCode() || 2014 == e.getErrorCode() || "lost" == e.getSQLState())
    {
        try{
            m_con.reset(m_driver->connect(m_host, m_user, m_password));
            if (m_con)
            {
                m_con->setSchema(m_dbname);
                std::unique_ptr<sql::Statement> stmt(m_con->createStatement());
                stmt->execute("SET NAMES UTF8");
                Log(info, "reconnect mysql ok");
                ret = true;
            }
            else
            {
                Log(error, "reconnect mysql failed");
                ret = false;
            }
        }
        catch (sql::SQLException& e)
        {
            Log(error, "SQLException in %s(%s) on line %d ErrCode %d SQLState %s Reason %s"
                , __FILE__, __FUNCTION__, __LINE__, e.getErrorCode(), e.getSQLStateCStr(), e.what());
            ret = false;
        }
        return ret;
    }
}

sql::Statement* MySQLWrapper::CreateStatement()
{
    if (!m_con)
        throw sql::SQLException("DB not available", "lost");
    return m_con->createStatement();
}

sql::PreparedStatement* MySQLWrapper::PrepareStatement(const std::string& sql)
{
    if (!m_con)
        throw sql::SQLException("DB not available", "lost");
    return m_con->prepareStatement(sql);
}

sql::ResultSet* MySQLWrapper::ExecuteQuery(const std::string& sql)
{
    if (!m_con)
        throw sql::SQLException("DB not available", "lost");
    std::unique_ptr<sql::Statement> stmt(m_con->createStatement());
    return stmt->executeQuery(sql);
}

sql::ResultSet* MySQLWrapper::ExecuteQuery(std::shared_ptr<sql::Statement> stmt, const std::string& sql)
{
    if (!stmt)
        throw sql::SQLException("Transaction not available");
    return stmt->executeQuery(sql);
}

int MySQLWrapper::ExecuteUpdate(const std::string& sql)
{
    if (!m_con)
        throw sql::SQLException("DB not available", "lost");
    std::unique_ptr<sql::Statement> stmt(m_con->createStatement());
    return stmt->executeUpdate(sql);
}

int MySQLWrapper::ExecuteUpdate(std::shared_ptr<sql::Statement> stmt, const std::string& sql)
{
    if (!stmt)
        throw sql::SQLException("Transaction not available");
    return stmt->executeUpdate(sql);
}

